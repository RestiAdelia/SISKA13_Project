<!DOCTYPE html>
<html>
<head>
    <title>OTP Verifikasi</title>
</head>
<body>
    <p>Halo,</p>
    <p>Berikut adalah kode OTP untuk mengganti password akun kamu:</p>
    <h2>{{ $otp }}</h2>
    <p>Kode ini berlaku sampai <strong>5 menit</strong>.</p>
    <p>Jika kamu tidak meminta perubahan ini, abaikan email ini.</p>
    <p>Terima kasih.</p>
</body>
</html>
