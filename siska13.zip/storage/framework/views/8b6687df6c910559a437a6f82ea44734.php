<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-bold text-3xl text-[var(--dark2)] leading-tight">
            <?php echo e(__('Data Guru dan Staff')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="p-6 bg-gray-50 min-h-screen" x-data="{ search: '' }">

        <div class="mb-10">
            <div class="text-center mb-10">
                <h2 class="font-bold text-3xl text-black border-b-2 border-pink-600 pb-3 **w-1/2** **mx-auto**">
                    Data Guru dan Staf
                </h2>
            </div>
        </div>

        <div class="flex items-center justify-between mb-6 gap-3">

            
            <div class="flex-1 max-w-md w-full">
                <input type="text" x-model="search" placeholder="🔍 Cari nama, NIP, atau jabatan..."
                    class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-700">
            </div>
            <div>
                <a href="<?php echo e(route('guru_dan_staff.create')); ?>"
                    class="bg-[#560029] hover:bg-[#3f0020] text-white px-5 py-3 rounded-lg font-semibold shadow-md transition-all duration-300 transform hover:scale-105">
                    ➕ Tambah Data
                </a>

            </div>
        </div>

        
        <div class="overflow-x-auto bg-white rounded-xl shadow-md">
            <table class="w-full border border-gray-200 text-sm text-gray-700 table-auto">
                <thead class="bg-gray-100 text-gray-800 font-semibold">
                    <tr>
                        <th class="px-4 py-2 border">No</th>
                        <th class="px-4 py-2 border">Foto</th>
                        <th class="px-4 py-2 border">Nama</th>
                        <th class="px-4 py-2 border">NIP</th>
                        <th class="px-4 py-2 border">Jenis Kelamin</th>
                        <th class="px-4 py-2 border">Jabatan</th>
                        <th class="px-4 py-2 border">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border hover:bg-gray-50 text-center"
                            x-show="
                                '<?php echo e(strtolower($pegawai->nama)); ?>'.includes(search.toLowerCase()) ||
                                '<?php echo e(strtolower($pegawai->nip)); ?>'.includes(search.toLowerCase()) ||
                                '<?php echo e(strtolower($pegawai->jabatan)); ?>'.includes(search.toLowerCase())
                            ">
                            <td class="px-4 py-2"><?php echo e($index + 1); ?></td>
                            <td class="px-4 py-2">
                                <?php if($pegawai->foto): ?>
                                    <img src="<?php echo e(asset('uploads/' . $pegawai->foto)); ?>"
                                        class="w-12 h-12 rounded-full object-cover mx-auto">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('images/default-user.png')); ?>"
                                        class="w-12 h-12 rounded-full object-cover mx-auto">
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-2"><?php echo e($pegawai->nama); ?></td>
                            <td class="px-4 py-2"><?php echo e($pegawai->nip); ?></td>
                            <td class="px-4 py-2"><?php echo e($pegawai->jenis_kelamin); ?></td>
                            <td class="px-4 py-2"><?php echo e($pegawai->jabatan); ?></td>
                            <td class="px-4 py-2 flex justify-center items-center gap-2">
                                
                                <a href="<?php echo e(route('guru_dan_staff.show', $pegawai->id)); ?>"
                                    class="px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition inline-flex items-center gap-1">
                                    <i class="fa-solid fa-eye"></i>
                                </a>

                                
                                <a href="<?php echo e(route('guru_dan_staff.edit', $pegawai->id)); ?>"
                                    class="px-3 py-1 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 transition inline-flex items-center gap-1">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>
                                <form action="<?php echo e(route('guru_dan_staff.destroy', $pegawai->id)); ?>" method="POST"
                                    class="delete-form inline-block">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button"
                                        class="px-3 py-1 bg-red-600 text-white rounded-md hover:bg-red-700 transition inline-flex items-center gap-1 btn-delete">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-gray-500 py-4">Tidak ada data tersedia</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <script src="//unpkg.com/alpinejs" defer></script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/guru_dan_staff/index.blade.php ENDPATH**/ ?>