<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-bold text-3xl text-[var(--dark2)] leading-tight">
            <?php echo e(__('Edit Data Kelas')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8 px-6 max-w-3xl mx-auto">
        <div class="bg-white p-6 rounded-lg shadow-md border"
             x-data="{
                tahunAjar: '<?php echo e(old('tahun_ajar', $kelas->tahun_ajar ?? '')); ?>',
                generateTahunAjar() {
                    const now = new Date();
                    const tahunSekarang = now.getFullYear();
                    const tahunDepan = tahunSekarang + 1;
                    this.tahunAjar = `${tahunSekarang}/${tahunDepan}`;
                }
             }"
             x-init="if(!tahunAjar) generateTahunAjar()">

            
            <?php if($errors->any()): ?>
                <div class="bg-red-100 text-red-800 border border-red-300 px-4 py-2 rounded mb-4">
                    <ul class="list-disc ml-5 text-sm">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('kelas.update', $kelas->id)); ?>" method="POST" class="space-y-5">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <div>
                    <label for="nama_kelas" class="block font-semibold mb-1">Nama Kelas</label>
                    <input 
                        type="text" 
                        id="nama_kelas" 
                        name="nama_kelas" 
                        value="<?php echo e(old('nama_kelas', $kelas->nama_kelas)); ?>"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        placeholder="Masukkan nama kelas..." 
                        required
                    >
                </div>

                
                <div>
                    <label for="guru_id" class="block font-semibold mb-1">Guru Pengampu</label>
                    <select 
                        name="guru_id" 
                        id="guru_id"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    >
                        <option value="">-- Pilih Guru --</option>
                        <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($g->id); ?>" 
                                <?php echo e(old('guru_id', $kelas->guru_id) == $g->id ? 'selected' : ''); ?>>
                                <?php echo e($g->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div>
                    <label for="tahun_ajar" class="block font-semibold mb-1">Tahun Ajar</label>
                    <input 
                        type="text" 
                        id="tahun_ajar" 
                        name="tahun_ajar" 
                        x-model="tahunAjar"
                        value="<?php echo e(old('tahun_ajar', $kelas->tahun_ajar)); ?>"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        placeholder="Contoh: 2024/2025" 
                        required
                    >
                    <p class="text-gray-500 text-sm mt-1">*Otomatis diisi berdasarkan tahun sekarang, bisa diubah jika perlu.</p>
                </div>

                
                <div class="flex justify-end gap-3">
                    <a href="<?php echo e(route('kelas.index')); ?>" 
                       class="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition">
                        Kembali
                    </a>
                    <button type="submit" 
                            class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                        Update
                    </button>
                </div>
            </form>
        </div>
    </div>

    
    <script src="//unpkg.com/alpinejs" defer></script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/kelas/edit.blade.php ENDPATH**/ ?>