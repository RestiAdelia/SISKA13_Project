<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Visi Misi')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-10 bg-gray-50 min-h-screen">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-xl sm:rounded-lg p-8">

                <?php if(session('error')): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4"
                        role="alert">
                        <span class="block sm:inline"><?php echo e(session('error')); ?></span>
                    </div>
                <?php endif; ?>

                
                <?php if($errors->any()): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4">
                        <strong class="font-bold">Gagal Update!</strong>
                        <span class="block sm:inline">Terdapat kesalahan input:</span>
                        <ul class="mt-2 list-disc list-inside">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>


                <form action="<?php echo e(route('visi-misi.update', $visimisi->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-5">
                        <label for="nama_sekolah" class="block text-sm font-semibold text-gray-700 mb-1">Nama
                            Sekolah</label>
                        <input type="text" id="nama_sekolah" name="nama_sekolah"
                            value="<?php echo e(old('nama_sekolah', $visimisi->nama_sekolah)); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-3"
                            required>
                        <?php $__errorArgs = ['nama_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-5">
                        <label for="akreditasi"
                            class="block text-sm font-semibold text-gray-700 mb-1">Akreditasi</label>
                        <input type="text" id="akreditasi" name="akreditasi"
                            value="<?php echo e(old('akreditasi', $visimisi->akreditasi)); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-3"
                            required>
                        <?php $__errorArgs = ['akreditasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-6">
                        <label for="visi" class="block text-sm font-semibold text-gray-700 mb-1">Visi</label>
                        <textarea id="visi" name="visi" rows="3"
                            class="w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-3" required><?php echo e(old('visi', $visimisi->visi)); ?></textarea>
                        <?php $__errorArgs = ['visi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-6 border-t pt-4">
                        <label class="block text-lg font-bold text-gray-800 mb-3">Daftar Misi</label>
                        <p class="text-sm text-gray-500 mb-4">Input setiap poin misi pada baris terpisah (minimal 1
                            misi).</p>

                        <div id="misi-container" class="space-y-3">
                            <?php
                                // Pastikan data misi berupa string sebelum di-explode
                                $misiString = is_string($visimisi->misi) ? $visimisi->misi : '';
                                $misiList = explode("\n", $misiString);
                                $misiListFiltered = array_filter($misiList, 'trim');

                                if (empty($misiListFiltered)) {
                                    $misiListFiltered[] = '';
                                }
                            ?>

                            <?php $__currentLoopData = $misiListFiltered; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $misiItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div
                                    class="misi-item flex gap-2 items-center bg-white shadow-sm p-3 rounded-lg border border-gray-200">
                                    <input type="text" name="misi_item[]" value="<?php echo e(trim($misiItem)); ?>"
                                        placeholder="Tuliskan poin misi ke-<?php echo e($loop->iteration); ?>"
                                        class="w-full border-gray-300 rounded-lg focus:border-green-500 focus:ring-green-500 p-2"
                                        required>
                                    <button type="button" class="remove-misi-btn text-red-500 hover:text-red-700 p-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
                                            viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                        </svg>
                                    </button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <button type="button" id="add-misi-btn"
                            class="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-blue-600 border border-transparent rounded-lg font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 transition ease-in-out duration-150 shadow-md">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 4v16m8-8H4" />
                            </svg>
                            Tambah Poin Misi
                        </button>

                        
                        <input type="hidden" name="misi" id="final-misi-input" value="">
                        <?php $__errorArgs = ['misi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-2">Error Misi: <?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <hr class="my-6 border-gray-200">

                    <div class="flex justify-end gap-3 mt-8">
                        <button type="submit" id="submit-form-btn"
                            class="inline-flex items-center px-6 py-3 border border-transparent rounded-lg font-semibold text-sm uppercase tracking-widest hover:bg-green-700 active:bg-green-800 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition ease-in-out duration-150 shadow-md"
                            style="background-color: #10B981 !important; color: white !important;">
                            UPDATE VISI MISI
                        </button>

                        <a href="<?php echo e(route('visi-misi.index')); ?>"
                            class="inline-flex items-center px-6 py-3 bg-white border border-gray-300 rounded-lg font-semibold text-sm text-gray-700 uppercase tracking-widest hover:bg-gray-100 active:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition ease-in-out duration-150 shadow-md">
                            BATAL
                        </a>
                    </div>
                </form>

            </div>
        </div>
    </div>

    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const misiContainer = document.getElementById('misi-container');
            const addMisiBtn = document.getElementById('add-misi-btn');
            const form = document.querySelector('form');
            const finalMisiInput = document.getElementById('final-misi-input');

            // Fungsi untuk membuat input misi baru
            const createMisiItem = (value = '') => {
                const misiItems = misiContainer.querySelectorAll('.misi-item');
                const nextCount = misiItems.length + 1;

                const div = document.createElement('div');
                div.classList.add('misi-item', 'flex', 'gap-2', 'items-center', 'bg-white', 'shadow-sm', 'p-3',
                    'rounded-lg', 'border', 'border-gray-200');
                div.innerHTML = `
                    <input type="text" name="misi_item[]" value="${value}"
                        placeholder="Tuliskan poin misi ke-${nextCount}"
                        class="w-full border-gray-300 rounded-lg focus:border-green-500 focus:ring-green-500 p-2" required>
                    <button type="button" class="remove-misi-btn text-red-500 hover:text-red-700 p-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                    </button>
                `;
                return div;
            };

            // Logika Tambah Misi
            addMisiBtn.addEventListener('click', function() {
                const newItem = createMisiItem();
                misiContainer.appendChild(newItem);
                updateMisiPlaceholders();
            });

            // Logika Hapus Misi (delegasi event)
            misiContainer.addEventListener('click', function(e) {
                if (e.target.closest('.remove-misi-btn')) {
                    const itemToRemove = e.target.closest('.misi-item');
                    // Minimal harus ada 1 input, jika kurang dari 1, bersihkan saja isinya
                    if (misiContainer.children.length > 1) {
                        itemToRemove.remove();
                        updateMisiPlaceholders();
                    } else {
                        // Jika hanya satu item tersisa, kita tidak menghapusnya, tapi mengosongkan nilainya
                        itemToRemove.querySelector('input[name="misi_item[]"]').value = '';
                    }
                    // Setelah operasi hapus/kosong, panggil fungsi untuk memastikan input hidden terisi
                    updateFinalMisiInput();
                }
            });

            // Fungsi untuk memperbarui penomoran placeholder
            const updateMisiPlaceholders = () => {
                const misiItems = misiContainer.querySelectorAll('.misi-item input[name="misi_item[]"]');
                misiItems.forEach((input, index) => {
                    input.placeholder = `Tuliskan poin misi ke-${index + 1}`;
                });
            };

            updateMisiPlaceholders();

            // Fungsi BARU: Mengambil, Menggabungkan, dan Mengisi input hidden
            const updateFinalMisiInput = () => {
                const misiItems = misiContainer.querySelectorAll('input[name="misi_item[]"]');
                const misiValues = [];

                misiItems.forEach(input => {
                    // Hanya ambil nilai yang tidak kosong setelah di-trim
                    const value = input.value.trim();
                    if (value) {
                        misiValues.push(value);
                    }
                });

                // Gabungkan semua nilai misi dengan baris baru (\n)
                finalMisiInput.value = misiValues.join('\n');
            };

            // Tambahkan event listener untuk setiap perubahan di input misi (untuk update real-time)
            misiContainer.addEventListener('input', updateFinalMisiInput);

            // Logika Gabungkan Misi saat Form disubmit
            form.addEventListener('submit', function(e) {
                // Panggil fungsi pengisian nilai di saat-saat terakhir sebelum submit
                updateFinalMisiInput();

                // Pastikan input hidden sudah terisi. Jika kosong, validasi Laravel yang akan menangani (yaitu "The misi field is required").

                // TIDAK PERLU e.preventDefault() dan form.submit() manual lagi
                // karena kita sudah memastikan nilai 'misi' terisi sebelum form dikirim secara alami.
            });

            // Panggil sekali saat DOM siap untuk mengisi input hidden dengan data awal
            updateFinalMisiInput();

        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/visi_misi/edit.blade.php ENDPATH**/ ?>