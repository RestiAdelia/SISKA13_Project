<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-extrabold text-4xl text-gray-800 leading-tight tracking-wide">
            <i class="fas fa-user-edit mr-3 text-[#560029]"></i>
            Edit Data Siswa: <span class="text-gray-600"><?php echo e($siswa->nama_siswa); ?></span>
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-10 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div class="bg-white p-8 rounded-2xl shadow-xl border border-gray-100">
            <form action="<?php echo e(route('siswa.update', $siswa->id)); ?>" method="POST">
                
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> 

                
                <h3 class="text-xl font-bold mb-6 text-gray-700 border-b pb-2">Informasi Utama Siswa</h3>
                <div class="mb-5">
                    <label for="nama_siswa" class="block text-sm font-medium text-gray-700 mb-2">Nama Siswa</label>
                    <input type="text" name="nama_siswa" id="nama_siswa" 
                        value="<?php echo e(old('nama_siswa', $siswa->nama_siswa)); ?>"
                        class="w-full border-gray-300 rounded-xl px-4 py-2.5 
                               focus:border-[#560029] focus:ring-[#560029] transition duration-300 
                               <?php $__errorArgs = ['nama_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        required placeholder="Masukkan nama lengkap siswa">
                    <?php $__errorArgs = ['nama_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-5">
                    <div>
                        <label for="nipd" class="block text-sm font-medium text-gray-700 mb-2">NIPD</label>
                        <input type="number" name="nipd" id="nipd" 
                            value="<?php echo e(old('nipd', $siswa->nipd)); ?>"
                            class="w-full border-gray-300 rounded-xl px-4 py-2.5 
                                   focus:border-[#560029] focus:ring-[#560029] transition duration-300
                                   <?php $__errorArgs = ['nipd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required placeholder="Nomor Induk Peserta Didik">
                        <?php $__errorArgs = ['nipd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="nisn" class="block text-sm font-medium text-gray-700 mb-2">NISN</label>
                        <input type="number" name="nisn" id="nisn" 
                            value="<?php echo e(old('nisn', $siswa->nisn)); ?>"
                            class="w-full border-gray-300 rounded-xl px-4 py-2.5 
                                   focus:border-[#560029] focus:ring-[#560029] transition duration-300
                                   <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required placeholder="Nomor Induk Siswa Nasional">
                        <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <h3 class="text-xl font-bold mb-6 mt-8 text-gray-700 border-b pb-2">Informasi Pribadi</h3>
                <div class="mb-5">
                    <label for="jenis_kelamin" class="block text-sm font-medium text-gray-700 mb-2">Jenis Kelamin</label>
                    <select name="jenis_kelamin" id="jenis_kelamin"
                        class="w-full border-gray-300 rounded-xl px-4 py-2.5 appearance-none
                               focus:border-[#560029] focus:ring-[#560029] transition duration-300
                               <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        required>
                        <option value="" disabled>-- Pilih Jenis Kelamin --</option>
                        
                        <option value="L" <?php echo e(old('jenis_kelamin', $siswa->jenis_kelamin) == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                        <option value="P" <?php echo e(old('jenis_kelamin', $siswa->jenis_kelamin) == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                    </select>
                    <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-5">
                    <div>
                        <label for="tempat_lahir" class="block text-sm font-medium text-gray-700 mb-2">Tempat Lahir</label>
                        <input type="text" name="tempat_lahir" id="tempat_lahir" 
                            value="<?php echo e(old('tempat_lahir', $siswa->tempat_lahir)); ?>"
                            class="w-full border-gray-300 rounded-xl px-4 py-2.5 
                                   focus:border-[#560029] focus:ring-[#560029] transition duration-300
                                   <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required placeholder="Contoh: Jakarta">
                        <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="tanggal_lahir" class="block text-sm font-medium text-gray-700 mb-2">Tanggal Lahir</label>
                        <input type="date" name="tanggal_lahir" id="tanggal_lahir" 
                            value="<?php echo e(old('tanggal_lahir', $siswa->tanggal_lahir)); ?>"
                            class="w-full border-gray-300 rounded-xl px-4 py-2.5 
                                   focus:border-[#560029] focus:ring-[#560029] transition duration-300
                                   <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required>
                        <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <h3 class="text-xl font-bold mb-6 mt-8 text-gray-700 border-b pb-2">Informasi Akademik</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-5">
                    <div>
                        <label for="kelas_id" class="block text-sm font-medium text-gray-700 mb-2">Kelas</label>
                        <select name="kelas_id" id="kelas_id"
                            class="w-full border-gray-300 rounded-xl px-4 py-2.5 appearance-none
                                   focus:border-[#560029] focus:ring-[#560029] transition duration-300
                                   <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value="" disabled>-- Pilih Kelas --</option>
                            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k->id); ?>" <?php echo e(old('kelas_id', $siswa->kelas_id) == $k->id ? 'selected' : ''); ?>>
                                    <?php echo e($k->nama_kelas); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="tahun_ajar" class="block text-sm font-medium text-gray-700 mb-2">Tahun Ajaran</label>
                        <select name="tahun_ajar" id="tahun_ajar"
                            class="w-full border-gray-300 rounded-xl px-4 py-2.5 appearance-none
                                   focus:border-[#560029] focus:ring-[#560029] transition duration-300
                                   <?php $__errorArgs = ['tahun_ajar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 ring-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value="" disabled>-- Pilih Tahun Ajaran --</option>
                            <?php $__currentLoopData = $tahunAjarList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ta); ?>" <?php echo e(old('tahun_ajar', $siswa->tahun_ajar) == $ta ? 'selected' : ''); ?>>
                                    <?php echo e($ta); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['tahun_ajar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <h3 class="text-xl font-bold mb-6 mt-8 text-gray-700 border-b pb-2">Informasi Kontak & Alamat</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-5">
                    <div>
                        <label for="orangtua_laki_laki" class="block text-sm font-medium text-gray-700 mb-2">Nama Ayah (Opsional)</label>
                        <input type="text" name="orangtua_laki_laki" id="orangtua_laki_laki"
                            value="<?php echo e(old('orangtua_laki_laki', $siswa->orangtua_laki_laki)); ?>"
                            class="w-full border-gray-300 rounded-xl px-4 py-2.5 
                                   focus:border-[#560029] focus:ring-[#560029] transition duration-300"
                            placeholder="Nama Ayah Kandung/Wali">
                    </div>
                    <div>
                        <label for="orangtua_perempuan" class="block text-sm font-medium text-gray-700 mb-2">Nama Ibu (Opsional)</label>
                        <input type="text" name="orangtua_perempuan" id="orangtua_perempuan"
                            value="<?php echo e(old('orangtua_perempuan', $siswa->orangtua_perempuan)); ?>"
                            class="w-full border-gray-300 rounded-xl px-4 py-2.5 
                                   focus:border-[#560029] focus:ring-[#560029] transition duration-300"
                            placeholder="Nama Ibu Kandung/Wali">
                    </div>
                </div>

                <div class="mb-5">
                    <label for="alamat" class="block text-sm font-medium text-gray-700 mb-2">Alamat Lengkap</label>
                    <textarea name="alamat" id="alamat" rows="4"
                        class="w-full border-gray-300 rounded-xl px-4 py-2.5 
                               focus:border-[#560029] focus:ring-[#560029] transition duration-300"
                    ><?php echo e(old('alamat', $siswa->alamat)); ?></textarea>
                </div>

                
                <div class="flex justify-end gap-4 mt-8 pt-4 border-t border-gray-100">
                    <a href="<?php echo e(route('siswa.index')); ?>"
                        class="px-6 py-2 border border-gray-300 text-gray-700 rounded-xl 
                               hover:bg-gray-50 transition duration-300 flex items-center">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Kembali
                    </a>
                    <button type="submit"
                        class="bg-[#560029] hover:bg-[#3f0020] text-white px-5 py-3 rounded-xl font-semibold shadow-lg shadow-[#560029]/30
                               transition duration-300 transform hover:scale-105 flex items-center">
                        <i class="fas fa-sync-alt mr-2"></i>
                        Update Data
                    </button>
                </div>

            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/siswa/edit.blade.php ENDPATH**/ ?>