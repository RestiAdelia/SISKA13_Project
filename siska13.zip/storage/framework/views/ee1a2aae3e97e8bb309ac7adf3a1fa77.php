<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-bold text-3xl text-[var(--dark2)] leading-tight">
            <?php echo e(__('Edit Data Guru dan Staff')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto px-4 py-8">
        <h2 class="text-2xl font-bold mb-6">Edit Guru / Staf</h2>

        <form action="<?php echo e(route('guru_dan_staff.update', $item->id)); ?>" method="POST" enctype="multipart/form-data"
            class="bg-white p-6 rounded shadow-md space-y-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="grid grid-cols-2 gap-4">

                
                <div>
                    <label class="block text-gray-700">NIP</label>
                    <input type="text" name="nip" class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->nip); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">Nama</label>
                    <input type="text" name="nama" class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->nama); ?>" required>
                </div>

                
                <div>
                    <label class="block text-gray-700">Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->tempat_lahir); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->tanggal_lahir ? \Carbon\Carbon::parse($item->tanggal_lahir)->format('Y-m-d') : ''); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">Jenis Kelamin</label>
                    <select name="jenis_kelamin" class="w-full border border-gray-300 rounded px-3 py-2">
                        <option value="">-- Pilih --</option>
                        <option value="L" <?php echo e($item->jenis_kelamin == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                        <option value="P" <?php echo e($item->jenis_kelamin == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                    </select>
                </div>

                
                <div>
                    <label class="block text-gray-700">Karpeg</label>
                    <input type="text" name="karpeg" class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->karpeg); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">NUPTK</label>
                    <input type="text" name="nuptk" class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->nuptk); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">NPWP</label>
                    <input type="text" name="npwp" class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->npwp); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">Pangkat/Golongan</label>
                    <input type="text" name="pangkat_golongan"
                        class="w-full border border-gray-300 rounded px-3 py-2" value="<?php echo e($item->pangkat_golongan); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">SK Pangkat Terakhir</label>
                    <input type="text" name="sk_pangkat_terakhir"
                        class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->sk_pangkat_terakhir); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">Jabatan</label>
                    <input type="text" name="jabatan" class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->jabatan); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">Pendidikan Terakhir</label>
                    <input type="text" name="pendidikan_terakhir"
                        class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->pendidikan_terakhir); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">TMT KGB Terakhir</label>
                    <input type="date" name="tmt_kgb_terakhir"
                        class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->tmt_kgb_terakhir ? \Carbon\Carbon::parse($item->tmt_kgb_terakhir)->format('Y-m-d') : ''); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">Sertifikasi</label>
                    <input type="text" name="sertifikasi" class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->sertifikasi); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">TMT Bertugas</label>
                    <input type="date" name="tmt_bertugas" class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->tmt_bertugas ? \Carbon\Carbon::parse($item->tmt_bertugas)->format('Y-m-d') : ''); ?>">
                </div>

                
                <div class="col-span-2">
                    <label class="block text-gray-700">Alamat</label>
                    <textarea name="alamat" class="w-full border border-gray-300 rounded px-3 py-2" rows="3"><?php echo e($item->alamat); ?></textarea>
                </div>

                
                <div>
                    <label class="block text-gray-700">Rencana Pensiun</label>
                    <input type="date" name="rencana_pensiun" class="w-full border border-gray-300 rounded px-3 py-2"
                        value="<?php echo e($item->rencana_pensiun ? \Carbon\Carbon::parse($item->rencana_pensiun)->format('Y-m-d') : ''); ?>">
                </div>

                
                <div>
                    <label class="block text-gray-700">Foto</label>
                    <?php if($item->foto): ?>
                        <img src="<?php echo e(asset('uploads/' . $item->foto)); ?>" alt="Foto"
                            class="w-20 h-20 object-cover rounded mb-2">
                    <?php endif; ?>
                    <input type="file" name="foto" class="w-full border border-gray-300 rounded px-3 py-2"
                        accept="image/*">
                </div>
            </div>

            <div class="mt-4">
                <button type="submit"
                    class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">Update</button>
                <a href="<?php echo e(route('guru_dan_staff.index')); ?>"
                    class="px-6 py-2 bg-gray-400 text-white rounded hover:bg-gray-500 transition">Batal</a>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/guru_dan_staff/edit.blade.php ENDPATH**/ ?>