<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-bold text-3xl text-gray-800 leading-tight">
                Detail Guru / Staff
            </h2>
            <a href="<?php echo e(route('guru_dan_staff.index')); ?>"
                class="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 transition">
                ← Kembali
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="bg-gray-50 min-h-screen py-10">
        <div class="max-w-5xl mx-auto bg-white shadow-lg rounded-2xl overflow-hidden">
            <div class="grid grid-cols-1 md:grid-cols-3">
                
                <div class="p-6 bg-gray-100 flex flex-col items-center justify-center border-r border-gray-200">
                    <?php if($guruDanStaff->foto): ?>
                        <img src="<?php echo e(asset('uploads/' . $guruDanStaff->foto)); ?>" alt="<?php echo e($guruDanStaff->nama); ?>"
                            class="rounded-xl shadow-md w-56 h-56 object-cover border border-gray-300">
                    <?php else: ?>
                        <div class="text-gray-500 italic">Tidak ada foto</div>
                    <?php endif; ?>

                    <h3 class="text-xl font-semibold text-gray-800 mt-4">
                        <?php echo e($guruDanStaff->nama); ?>

                    </h3>
                    <p class="text-gray-600"><?php echo e($guruDanStaff->jabatan ?? '-'); ?></p>
                </div>

                
                <div class="md:col-span-2 p-8">
                    <h4 class="text-lg font-bold text-pink-800 mb-4 border-b pb-2">Informasi Pribadi</h4>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-gray-700">
                        <div><span class="font-medium">NIP:</span> <?php echo e($guruDanStaff->nip ?? '-'); ?></div>
                        <div><span class="font-medium">Jenis Kelamin:</span>
                            <?php echo e($guruDanStaff->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?>

                        </div>
                        <div><span class="font-medium">Tempat Lahir:</span> <?php echo e($guruDanStaff->tempat_lahir ?? '-'); ?>

                        </div>
                        <div><span class="font-medium">Tanggal Lahir:</span>
                            <?php echo e($guruDanStaff->tanggal_lahir ? \Carbon\Carbon::parse($guruDanStaff->tanggal_lahir)->translatedFormat('d F Y') : '-'); ?>

                        </div>
                        <div><span class="font-medium">Alamat:</span> <?php echo e($guruDanStaff->alamat ?? '-'); ?></div>
                    </div>

                    <h4 class="text-lg font-bold text-pink-800 mt-8 mb-4 border-b pb-2">Informasi Kepegawaian</h4>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-gray-700">
                        <div><span class="font-medium">No Karpeg:</span> <?php echo e($guruDanStaff->no_karpeg ?? '-'); ?></div>
                        <div><span class="font-medium">NUPTK:</span> <?php echo e($guruDanStaff->nuptk ?? '-'); ?></div>
                        <div><span class="font-medium">NPWP:</span> <?php echo e($guruDanStaff->npwp ?? '-'); ?></div>
                        <div><span class="font-medium">Pangkat/Golongan:</span>
                            <?php echo e($guruDanStaff->pangkat_golongan ?? '-'); ?></div>
                        <div><span class="font-medium">SK Nomor:</span> <?php echo e($guruDanStaff->sk_nomor ?? '-'); ?></div>
                        <div><span class="font-medium">SK Tanggal:</span>
                            <?php echo e($guruDanStaff->sk_tanggal ? \Carbon\Carbon::parse($guruDanStaff->sk_tanggal)->translatedFormat('d F Y') : '-'); ?>

                        </div>
                        <div><span class="font-medium">SK TMT:</span>
                            <?php echo e($guruDanStaff->sk_tmt ? \Carbon\Carbon::parse($guruDanStaff->sk_tmt)->translatedFormat('d F Y') : '-'); ?>

                        </div>
                        <div><span class="font-medium">Angka Kredit:</span> <?php echo e($guruDanStaff->angka_kredit ?? '-'); ?>

                        </div>
                        <div><span class="font-medium">Masa Kerja:</span>
                            <?php echo e($guruDanStaff->masa_kerja_tahun ?? 0); ?> Tahun
                            <?php echo e($guruDanStaff->masa_kerja_bulan ?? 0); ?> Bulan
                        </div>
                        <div><span class="font-medium">Pendidikan Terakhir:</span>
                            <?php echo e($guruDanStaff->pendidikan_terakhir ?? '-'); ?>

                        </div>
                        <div>
                            <span class="font-medium">TMT_KGB_TERAKHIR</span>
                            <?php echo e($guruDanStaff->tmt_kgb_terakhir ? \Carbon\Carbon::parse($guruDanStaff->tmt_kgb_terakhir)->translatedFormat('d F Y') : '-'); ?>



                        </div>

                        <div><span class="font-medium">Sertifikasi:</span> <?php echo e($guruDanStaff->sertifikasi ?? '-'); ?>

                        </div>
                        <div><span class="font-medium">TMT Bertugas:</span>
                            <?php echo e($guruDanStaff->tmt_bertugas ? \Carbon\Carbon::parse($guruDanStaff->tmt_bertugas)->translatedFormat('d F Y') : '-'); ?>

                        </div>
                        <div><span class="font-medium">Keterangan:</span> <?php echo e($guruDanStaff->ket ?? '-'); ?></div>
                    </div>

                    
                    <div class="mt-10 flex justify-end gap-3">
                        <a href="<?php echo e(route('guru_dan_staff.edit', $guruDanStaff->id)); ?>"
                            class="px-5 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                            Edit Data
                        </a>
                        
                        <a href="<?php echo e(route('guru_dan_staff.index')); ?>"
                            class="px-5 py-2 bg-red-600 text-white rounded-lg hover:bg-white-700 transition">
                            ← Kembali
                        </a>


                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/guru_dan_staf/show.blade.php ENDPATH**/ ?>