<?php $__env->startSection('header'); ?>
    <h2 class="font-bold text-3xl text-gray-800 leading-tight">
        <?php echo e(__('Detail Kegiatan')); ?>

    </h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-10 bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
        <div class="max-w-4xl mx-auto bg-white p-8 rounded-2xl shadow-lg">
            <!-- Gambar -->
            <?php if($kegiatan->gambar_kegiatan): ?>
                <img src="<?php echo e(asset('storage/' . $kegiatan->gambar_kegiatan)); ?>" alt="<?php echo e($kegiatan->nama_kegiatan); ?>"
                    class="w-full h-80 object-cover rounded-lg mb-6 shadow-md">
            <?php endif; ?>

            <!-- Info Kegiatan -->
            <h1 class="text-3xl font-bold text-gray-800 mb-4"><?php echo e($kegiatan->nama_kegiatan); ?></h1>
            <p class="text-gray-600 mb-2">
                <strong>Tanggal:</strong>
                <?php echo e(\Carbon\Carbon::parse($kegiatan->tanggal_kegiatan)->translatedFormat('d F Y')); ?>

            </p>

            <?php if($kegiatan->deskripsi): ?>
                <div class="mt-4">
                    <h3 class="text-lg font-semibold text-gray-800 mb-2">Deskripsi Kegiatan:</h3>
                    <p class="text-gray-700 leading-relaxed"><?php echo e($kegiatan->deskripsi); ?></p>
                </div>
            <?php endif; ?>

            <!-- Tombol Kembali -->
            <div class="mt-8">
                <a href="<?php echo e(url('/#kegiatan')); ?>"
                    class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-lg font-semibold shadow-md transition-all duration-300">
                    ← Kembali ke Beranda
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/kegiatan/show.blade.php ENDPATH**/ ?>