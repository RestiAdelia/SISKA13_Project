
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-bold text-3xl text-[var(--dark2)] leading-tight">
            <?php echo e(__('Data Kelas')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8 px-6 max-w-6xl mx-auto" 
         x-data="{ 
            search: '<?php echo e(request('search')); ?>', 
            tahunAjar: '<?php echo e(request('tahun_ajar')); ?>' 
         }">

        
        <div class="flex flex-wrap items-center justify-between mb-6 gap-3">
            
            <div class="flex-1 max-w-md w-full">
                <form method="GET" action="<?php echo e(route('kelas.index')); ?>" class="flex gap-2">
                    <input 
                        type="text" 
                        name="search" 
                        x-model="search"
                        value="<?php echo e(request('search')); ?>"
                        placeholder="🔍 Cari nama kelas atau guru pengampu..."
                        class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-700">

                    
                    <select 
                        name="tahun_ajar"
                        x-model="tahunAjar"
                        onchange="this.form.submit()"
                        class="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-700"
                    >
                        <option value="">Semua </option>
                        <?php $__currentLoopData = $daftar_tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tahun); ?>" <?php echo e(request('tahun_ajar') == $tahun ? 'selected' : ''); ?>>
                                <?php echo e($tahun); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>
            </div>

            
            <div>
                <a href="<?php echo e(route('kelas.create')); ?>"
                    class="bg-[#560029] hover:bg-[#3f0020] text-white px-5 py-3 rounded-lg font-semibold shadow-md transition-all duration-300 transform hover:scale-105">
                    ➕ Tambah Kelas
                </a>
            </div>
        </div>

        
        <div class="bg-white p-6 rounded-lg shadow-md border overflow-x-auto">
            <table class="min-w-full border border-gray-200">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left border">No</th>
                        <th class="px-4 py-2 text-left border">Nama Kelas</th>
                        <th class="px-4 py-2 text-left border">Guru Pengampu</th>
                        <th class="px-4 py-2 text-left border">Tahun Ajar</th>
                        <th class="px-4 py-2 text-center border w-32">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-t hover:bg-gray-50 transition">
                            <td class="px-4 py-2 border"><?php echo e($kelas->firstItem() + $index); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($k->nama_kelas); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($k->guru->nama ?? '-'); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($k->tahun_ajar); ?></td>
                            <td class="px-4 py-2 text-center space-x-2">
                                
                                <a href="<?php echo e(route('kelas.edit', $k->id)); ?>"
                                    class="px-2 py-1 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 transition inline-flex items-center gap-1 text-sm">
                                    <i class="fa-solid fa-pen-to-square text-xs"></i>
                                </a>

                                
                                <form action="<?php echo e(route('kelas.destroy', $k->id)); ?>" method="POST" class="inline delete-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button" class="btn-delete text-red-600 hover:text-red-800 transition text-sm" title="Hapus">
                                        <i class="fa-solid fa-trash text-xs"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center py-4 text-gray-500">Belum ada data kelas.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            
            <div class="mt-4">
                <?php echo e($kelas->appends(request()->query())->links()); ?>

            </div>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="//unpkg.com/alpinejs" defer></script>  
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/kelas/index.blade.php ENDPATH**/ ?>