<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class="max-w-md mx-auto bg-white shadow-xl rounded-2xl p-8 mt-10 border border-gray-100">
    <h2 class="text-3xl font-extrabold text-[#560029] text-center mb-8 flex items-center justify-center">
        <i class="fas fa-paper-plane mr-3"></i>
        
        Kirim OTP ke Email
    </h2>

    
    <?php if(session('status')): ?>
        <div class="bg-green-50 border border-green-200 text-green-700 p-4 rounded-xl mb-6 text-sm font-medium shadow-sm">
            <i class="fas fa-check-circle mr-2"></i> <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl mb-6 text-sm font-medium shadow-sm">
            <i class="fas fa-times-circle mr-2"></i> <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('password.sendOtp')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <p class="text-gray-600 text-base mb-6 text-center">
            Tekan tombol di bawah untuk mengirimkan **kode OTP** ke alamat email Anda yang terdaftar.
        </p>

        <button type="submit"
            class="w-full bg-[#560029] hover:bg-[#3f0020] text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-[#560029]/40 transition duration-300 transform hover:scale-[1.01] flex items-center justify-center">
            <i class="fas fa-envelope mr-2"></i>
            Kirim Kode OTP
        </button>
    </form>
    
    
    <div class="mt-6 text-center">
        <a href="<?php echo e(route('profile.show')); ?>" class="text-gray-500 hover:text-gray-700 text-sm underline transition duration-200">
            Kembali ke profile
        </a>
    </div>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/auth/send-otp.blade.php ENDPATH**/ ?>