<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class="max-w-lg mx-auto bg-white shadow-xl rounded-2xl p-8 mt-10 border border-gray-100">
    <h2 class="text-3xl font-extrabold text-[#560029] text-center mb-8 flex items-center justify-center">
        <i class="fas fa-lock mr-3"></i>
        Ubah Password
    </h2>

    
    <?php if(session('status')): ?>
        <div class="bg-green-50 border border-green-200 text-green-700 p-4 rounded-xl mb-6 text-sm font-medium shadow-sm">
            <i class="fas fa-check-circle mr-2"></i> <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl mb-6 text-sm font-medium shadow-sm">
            <ul class="list-disc list-inside">
                <p class="font-bold mb-1">Terjadi Kesalahan:</p>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('password.updatePassword')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        
        <div class="mb-5">
            <label class="block text-gray-700 font-medium mb-1">Password Baru</label>
            <input type="password" name="password"
                
                class="block w-full border-gray-300 rounded-xl p-3 shadow-sm focus:ring-0 focus:border-gray-500 transition duration-200"
                required>
            
        </div>

        
        <div class="mb-8">
            <label class="block text-gray-700 font-medium mb-1">Konfirmasi Password</label>
            <input type="password" name="password_confirmation"
                
                class="block w-full border-gray-300 rounded-xl p-3 shadow-sm focus:ring-0 focus:border-gray-500 transition duration-200"
                required>
        </div>

        
        <button type="submit"
            
            class="w-full bg-[#560029] hover:bg-[#3f0020] text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-[#560029]/40 transition duration-300 transform hover:scale-[1.01] flex items-center justify-center">
            <i class="fas fa-save mr-2"></i>
            Simpan Password Baru
        </button>
    </form>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/auth/update-password.blade.php ENDPATH**/ ?>