<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <div class="bg-white rounded-lg shadow p-4 flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Jumlah Siswa</p>
                <h2 class="text-2xl font-bold text-pink-600">1,250</h2>
            </div>
            <span class="text-3xl">👨‍🎓</span>
        </div>
        <div class="bg-white rounded-lg shadow p-4 flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Jumlah Guru</p>
                <h2 class="text-2xl font-bold text-pink-600">85</h2>
            </div>
            <span class="text-3xl">👩‍🏫</span>
        </div>
        <div class="bg-white rounded-lg shadow p-4 flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Mata Pelajaran</p>
                <h2 class="text-2xl font-bold text-pink-600">42</h2>
            </div>
            <span class="text-3xl">📚</span>
        </div>
        <div class="bg-white rounded-lg shadow p-4 flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Pengumuman</p>
                <h2 class="text-2xl font-bold text-pink-600">7</h2>
            </div>
            <span class="text-3xl">📢</span>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/dashboard.blade.php ENDPATH**/ ?>