<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-bold text-3xl text-[var(--dark2)] leading-tight">
            <?php echo e(__('Data Siswa')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8 px-4 md:px-10 max-w-7xl mx-auto" x-data="{ tahunAjar: '<?php echo e(request('tahun_ajar')); ?>', kelasId: '<?php echo e(request('kelas_id')); ?>' }">

        
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <form method="GET" action="<?php echo e(route('siswa.index')); ?>"
                class="flex flex-wrap items-center gap-3 w-full md:w-auto" x-data x-on:change="$el.submit()"
                x-on:input.debounce.500ms="$el.submit()">

                
                <input type="text" name="search" placeholder=" 🔍 Cari nama siswa..."
                    value="<?php echo e(request('search')); ?>"
                    class="border rounded-lg px-4 py-2 text-base focus:ring-2 focus:ring-blue-500 min-w-[200px]">

                
                <select name="tahun_ajar"
                    class="border rounded-lg px-4 py-2 text-base focus:ring-2 focus:ring-blue-500 min-w-[150px]">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $tahunAjarList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ta); ?>" <?php echo e(request('tahun_ajar') == $ta ? 'selected' : ''); ?>>
                            <?php echo e($ta); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                
                <select name="kelas_id"
                    class="border rounded-lg px-4 py-2 text-base focus:ring-2 focus:ring-blue-500 min-w-[180px]">
                    <option value="">Semua Kelas</option>
                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>" <?php echo e(request('kelas_id') == $k->id ? 'selected' : ''); ?>>
                            <?php echo e($k->nama_kelas); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>

            
            <a href="<?php echo e(route('siswa.create')); ?>"
                class="bg-[#560029] hover:bg-[#3f0020] text-white px-5 py-3 rounded-lg font-semibold shadow-md transition duration-300 transform hover:scale-105">
                ➕ Tambah Siswa
            </a>
        </div>

        
        <div class="bg-white p-6 rounded-lg shadow-md border overflow-x-auto">
            <table class="min-w-full border border-gray-200 text-sm">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 border text-center">No</th>
                        <th class="px-4 py-2 border text-center">Nama</th>
                        <th class="px-4 py-2 border text-center">NIPD</th>
                        <th class="px-4 py-2 border text-center">NISN</th>
                        <th class="px-4 py-2 border text-center">Jenis Kelamin</th>
                        <th class="px-4 py-2 border text-center w-36">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-t hover:bg-gray-50 transition  ">
                            <td class="px-4 py-2 border "><?php echo e($loop->iteration); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($s->nama_siswa); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($s->nipd); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($s->nisn); ?></td>
                            <td class="px-4 py-2 border"><?php echo e($s->jenis_kelamin); ?></td>

                            </td>
                            <td class="px-4 py-2 text-center flex justify-center gap-2">

                                
                                <a href="<?php echo e(route('siswa.show', $s->id)); ?>"
                                    class="px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition inline-flex items-center gap-1">
                                    <i class="fa-solid fa-eye"></i>
                                </a>

                                
                                <a href="<?php echo e(route('siswa.edit', $s->id)); ?>"
                                    class="px-3 py-1 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 transition inline-flex items-center gap-1">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>
                                
                                 <form action=" route('siswa.destroy', $s->id) }}" method="POST"
                                    class="delete-form inline-block">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button"
                                        class="px-3 py-1 bg-red-600 text-white rounded-md hover:bg-red-700 transition inline-flex items-center gap-1 btn-delete">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-4 text-gray-500">Belum ada data siswa.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            
            <div class="mt-4">
                <?php echo e($siswa->appends(request()->query())->links()); ?>

            </div>
        </div>
    </div>

    <script src="//unpkg.com/alpinejs" defer></script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/siswa/index.blade.php ENDPATH**/ ?>