<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-bold text-3xl text-gray-800 leading-tight">
                <?php echo e(__('Tambah Data Guru dan Staff')); ?>

            </h2>
            <a href="<?php echo e(route('guru_dan_staff.index')); ?>"
                class="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 transition">
                ← Kembali
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="bg-gray-50 min-h-screen py-10">
        <div class="max-w-5xl mx-auto bg-white shadow-md rounded-lg p-8">
            <h3 class="text-xl font-semibold text-gray-800 mb-6 border-b pb-3">
                Formulir Tambah Guru / Staf
            </h3>

            <form action="<?php echo e(route('guru_dan_staff.store')); ?>" method="POST" enctype="multipart/form-data"
                class="space-y-6">
                <?php echo csrf_field(); ?>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Nama</label>
                        <input type="text" name="nama" value="<?php echo e(old('nama')); ?>" required
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">NIP</label>
                        <input type="number" name="nip" value="<?php echo e(old('nip')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Tempat Lahir</label>
                        <input type="text" name="tempat_lahir" value="<?php echo e(old('tempat_lahir')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal Lahir</label>
                        <input type="date" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Jenis Kelamin</label>
                        <select name="jenis_kelamin" class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                            <option value="">-- Pilih --</option>
                            <option value="L" <?php echo e(old('jenis_kelamin') == 'L' ? 'selected' : ''); ?>>Laki-laki
                            </option>
                            <option value="P" <?php echo e(old('jenis_kelamin') == 'P' ? 'selected' : ''); ?>>Perempuan
                            </option>
                        </select>
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">No Karpeg</label>
                        <input type="text" name="no_karpeg" value="<?php echo e(old('no_karpeg')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">NUPTK</label>
                        <input type="text" name="nuptk" value="<?php echo e(old('nuptk')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">NPWP</label>
                        <input type="text" name="npwp" value="<?php echo e(old('npwp')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Pangkat/Golongan</label>
                        <input type="text" name="pangkat_golongan" value="<?php echo e(old('pangkat_golongan')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">SK Nomor</label>
                        <input type="text" name="sk_nomor" value="<?php echo e(old('sk_nomor')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">SK Tanggal</label>
                        <input type="date" name="sk_tanggal" value="<?php echo e(old('sk_tanggal')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">SK TMT</label>
                        <input type="date" name="sk_tmt" value="<?php echo e(old('sk_tmt')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Angka Kredit</label>
                        <input type="number" step="0.001" name="angka_kredit" value="<?php echo e(old('angka_kredit')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Masa Kerja (Tahun)</label>
                        <input type="number" name="masa_kerja_tahun" value="<?php echo e(old('masa_kerja_tahun')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Masa Kerja (Bulan)</label>
                        <input type="number" name="masa_kerja_bulan" value="<?php echo e(old('masa_kerja_bulan')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Jabatan</label>
                        <select name="jabatan" class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                            <option value="">-- Pilih Jabatan --</option>
                            <option value="Kepala Sekolah" <?php echo e(old('jabatan') == 'Kepala Sekolah' ? 'selected' : ''); ?>>
                                Kepala Sekolah</option>
                            <option value="Guru" <?php echo e(old('jabatan') == 'Guru' ? 'selected' : ''); ?>>Guru</option>
                            <option value="Staf" <?php echo e(old('jabatan') == 'Staf' ? 'selected' : ''); ?>>Staf</option>
                        </select>
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Pendidikan Terakhir</label>
                        <input type="text" name="pendidikan_terakhir" value="<?php echo e(old('pendidikan_terakhir')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">TMT KGB Terakhir</label>
                        <input type="date" name="tmt_kgb_terakhir" value="<?php echo e(old('tmt_kgb_terakhir')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Sertifikasi</label>
                        <select name="sertifikasi" class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                            <option value="">-- Pilih --</option>
                            <option value="Sudah" <?php echo e(old('sertifikasi') == 'Sudah' ? 'selected' : ''); ?>>Sudah
                            </option>
                            <option value="Belum" <?php echo e(old('sertifikasi') == 'Belum' ? 'selected' : ''); ?>>Belum
                            </option>
                        </select>
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Keterangan</label>
                        <input type="text" name="ket" value="<?php echo e(old('ket')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">TMT Bertugas</label>
                        <input type="date" name="tmt_bertugas" value="<?php echo e(old('tmt_bertugas')); ?>"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>

                    
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Alamat</label>
                        <textarea name="alamat" rows="3" class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2"><?php echo e(old('alamat')); ?></textarea>
                    </div>

                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Foto</label>
                        <input type="file" name="foto" accept="image/*"
                            class="w-full border-gray-300 rounded-lg shadow-sm px-3 py-2">
                    </div>
                </div>

                
                <div class="pt-6 border-t flex justify-end gap-3">
                    <a href="<?php echo e(route('guru_dan_staff.index')); ?>"
                        class="px-5 py-2 bg-gray-400 text-white rounded-lg hover:bg-gray-500 transition">Batal</a>
                    <button type="submit"
                        class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">Simpan</button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\semester 5\Proyek Utama\project\SISKA13_Project\resources\views/guru_dan_staff/create.blade.php ENDPATH**/ ?>